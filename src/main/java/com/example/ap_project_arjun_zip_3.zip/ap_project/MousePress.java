package com.example.ap_project;

import javafx.scene.input.MouseEvent;

public interface MousePress {
    public void handleMousePress(MouseEvent event);
    public void handleMouseReleased(MouseEvent event);
}
