package com.example.ap_project;

import javafx.scene.input.MouseEvent;

public class PauseScreenController {
    public void loadhomescreen(MouseEvent event) {
    }

    public void loadgamescreen(MouseEvent event) {
    }

    public void continuegame(MouseEvent event) {
    }
}
